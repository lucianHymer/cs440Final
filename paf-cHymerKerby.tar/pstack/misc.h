#ifndef __MISC_H_INCLUDED
#define __MISC_H_INCLUDED

int yylex(void);

#endif
